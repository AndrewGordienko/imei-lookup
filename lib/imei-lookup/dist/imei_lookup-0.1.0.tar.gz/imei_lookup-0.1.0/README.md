Provides a description of your project, how to install and use it.
