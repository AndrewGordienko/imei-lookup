from setuptools import setup, find_packages

setup(
    name='imei-lookup',
    version='0.1.0',
    description='A library for looking up IMEI information',
    packages=find_packages(),
    install_requires=[],  # Add your dependencies here
)

